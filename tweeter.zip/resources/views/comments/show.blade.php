@extends('layouts.main')

@section('content')

    <div class="content-container">
         @include('comments._comment')

    </div>

@endsection
