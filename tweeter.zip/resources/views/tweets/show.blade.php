@extends('layouts.main')

@section('content')

    <div class="content-container">
         @include('tweets._tweet')
    </div>

@endsection
