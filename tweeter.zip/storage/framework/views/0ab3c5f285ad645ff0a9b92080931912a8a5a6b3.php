

<?php $__env->startSection('content'); ?>
    <div class="createtweet-container">
        <h3> Create a New Tweet </h3>
        <form action="/tweets" method="POST">
            <?php echo csrf_field(); ?>
            <p><textarea name="body" placeholder="What's on your mind?"class="form-control"></textarea></p>
            <button type="submit">Post</button>
        </form>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/tweets/create.blade.php ENDPATH**/ ?>