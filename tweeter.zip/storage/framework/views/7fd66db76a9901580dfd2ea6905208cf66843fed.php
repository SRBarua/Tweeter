
<?php $__env->startSection('content'); ?>
        <h2>Edit Profile</h2>
            <form action="/profiles/<?php echo e($profile->id); ?>" method="POST">
                <?php echo e(method_field('PUT')); ?>

                <?php echo csrf_field(); ?>
                <h4> Bio</h4>
                <p><textarea name="bio" placeholder="About yourself"><?php echo e($profile->bio); ?></textarea></p>
                <h4> Date of Birth</h4>
                <p><textarea name="birthday" placeholder="yyyy-mm-dd"><?php echo e($profile->birthday); ?></textarea></p>
                <h4>Location</h4>
                <p><textarea name="location" placeholder="City, State/Province"><?php echo e($profile->location); ?></textarea></p>
                <br />
                <button type="submit">Save</button>
            </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/profiles/edit.blade.php ENDPATH**/ ?>