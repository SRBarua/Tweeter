<div class="card mb-4" style="width:800px" padding-Left="10px">
    <div class="card-body">
        <img src="/img/user-310807_960_720.png" width="30px" height="30px">
        <h2><a href="/tweets/<?php echo e($tweet->id); ?>"><?php echo e($tweet->user->name); ?></a></h2>
        <p class="card-text"><?php echo e($tweet->body); ?></p>
            <?php if(Auth::id() == $tweet->user_id): ?>
                <a href="/tweets/<?php echo e($tweet->id); ?>/edit" class="btn btn-link">Edit</a>
                <form action="/tweets/<?php echo e($tweet->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-link" class="d-inline">Delete</button>
                </form>
             <?php endif; ?>
        <hr />
            <img src="/img/like.png" height="20px">
            <a href="/tweets/<?php echo e($tweet->id); ?>/like" class="btn btn-link p-0"> Like</a>
            (<?php echo e($tweet->likes()->count()); ?>)
            <img src="/img/comment.png" height="20px">
            <a href="/tweets/<?php echo e($tweet->id); ?>/comment"> Comment</a>
            (<?php echo e($tweet->comments()->count()); ?>)
            <img src="/img/160-512.png" height="20px">
            <a href="/tweets/<?php echo e($tweet->id); ?>/share"> Share</a>
        <hr />
        <div class="comment-container">
            <ul class="list-group">
                <?php $__currentLoopData = $tweet->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('comments._comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <br />
        <form action="/comments/<?php echo e($tweet->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
               <input type="text" name="body" class="form-control" />
               <input type="hidden" name="tweet_id" value="<?php echo e($tweet->id); ?>" />
            </div>
           <div class="form-group">
               <input type="submit" class="btn btn-warning d-inline" value="Post" />
           </div>
        </form>
    </div>
</div>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/tweets/_tweet.blade.php ENDPATH**/ ?>