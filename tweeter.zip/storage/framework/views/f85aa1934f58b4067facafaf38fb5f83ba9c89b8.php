<footer>
    <div class="footer-container text-center pt-1" style="background-color: #00FF00; padding-left:10px;">
        <p><span>2019-Copyright Tweeter </span> | <span> Tweeter CANADA </span> | <span> tweeter@gmail.com </span></p>
    </div>
</footer>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/layouts/_footer.blade.php ENDPATH**/ ?>