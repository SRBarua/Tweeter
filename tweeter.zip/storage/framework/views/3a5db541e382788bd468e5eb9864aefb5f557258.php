
<?php $__env->startSection('content'); ?>
    <div class="createprofile-container">
        <h3> Create your profile</h3>
        <form action="/profiles" method="POST">
            <?php echo csrf_field(); ?>
            <h4> Bio</h4>
            <p><textarea name="bio" placeholder="About yourself"></textarea></p>
            <h4> Date of Birth</h4>
            <p><textarea name="birthday" placeholder="yyyy-mm-dd"></textarea></p>
            <h4>Location</h4>
            <p><textarea name="location" placeholder="City, State/Province"></textarea></p>
            <br />
            <button type="submit">Save</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/profiles/create.blade.php ENDPATH**/ ?>