

<?php $__env->startSection('content'); ?>

    <div class="card" align="center">
            <?php echo $__env->make('profiles._profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div>Birthday: <?php echo e($profile->birthday); ?></div>
            <div>Location: <?php echo e($profile->location); ?></div>
            <div>Bio: <?php echo e($profile->bio); ?></div>
            <?php if(Auth::id() == $profile->user_id): ?>
                <a href="/profiles/<?php echo e($profile->id); ?>/edit">Edit</a>
            <?php endif; ?>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/profiles/show.blade.php ENDPATH**/ ?>