<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
        <link rel="stylesheet" href="/css/app.css" />
    </head>
    <body>
        <div id="app">
            <div class="container">
                <?php echo $__env->make('layouts._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <br />
                    <div class="content">
                        <?php echo $__env->make('layouts._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                <br />
                <?php echo $__env->make('layouts._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
            <script src="/js/app.js"></script>
    </body>
</html>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/layouts/main.blade.php ENDPATH**/ ?>