<li class="list-group-item">
    <div class="card-body">
        <strong><?php echo e($comment->user->name); ?></strong>
        <?php echo e($comment->created_at->diffForhumans()); ?>: &nbsp;
        <?php echo e($comment->body); ?>

        <?php if(Auth::id() == $tweet->user_id): ?>
        <a href="/comments/<?php echo e($comment->id); ?>/edit">Edit</a> |
        <form action="/comments/<?php echo e($comment->id); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
        </form>
        <?php endif; ?>
    </div>
 </li>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/comments/_comment.blade.php ENDPATH**/ ?>