<div class="sidebar">
    <div class="col">
        <ul class="postlist">
            <li><a href="#">Post 01</a></li>
            <li><a href="#">Post 02</a></li>
            <li><a href="#">Post 03</a></li>
            <li><a href="#">Post 04</a></li>
        </ul>
    </div>

</div>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/layouts/_sidebar.blade.php ENDPATH**/ ?>