<nav class="navbar navbar-expand-sm navbar-custom py-0" style="background-color: #00FF00;" width="100%">

        <!-- Brand -->
        <a class="navbar-brand" href="#">
            <img src="/img/twitter.png" style="height:40px">
        </a>

        <!-- Toggler/Collapsibe Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar" aria-controls="collapsibleNavbar" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar links -->
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e('/tweets'); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e('/profiles'); ?>">Profiles</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Settings</a>
                </li>
            </ul>

            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="position:relative; padding-left:50px;">
                        <img src="/img/<?php echo e(Auth::user()->avatar); ?>" style="width:28px; height:28px; position:absolute; top:10px; left:10px; border-radius:50%;">
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
</nav>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/layouts/_navbar.blade.php ENDPATH**/ ?>