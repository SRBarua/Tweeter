<?php $__env->startSection('content'); ?>
                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <img src="/img/<?php echo e($user->avatar); ?>" style="width:90px; height:90px; border-radius:50%" >
                            <h2> <?php echo e($user->name); ?>'s Profile </h2>
                            <form enctype="multipart/form-data" action="/profiles" method="POST">
                                <p><label>Update Profile Image</label></p>
                                <p><input type="file" name="avatar"></p>
                                <p><input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"></p>
                                <input type="submit" class="btn btn-sm btn-primary">
                            </form>
                        </div>
                            <a href=" /profiles/ "><button class="btn btn-primary"> Who to follow? </button></a>
                    </div>
                </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/profile.blade.php ENDPATH**/ ?>