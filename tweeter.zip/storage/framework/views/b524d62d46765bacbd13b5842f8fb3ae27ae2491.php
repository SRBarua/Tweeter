
<header>

        <?php echo $__env->make('layouts._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</header>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/layouts/_header.blade.php ENDPATH**/ ?>